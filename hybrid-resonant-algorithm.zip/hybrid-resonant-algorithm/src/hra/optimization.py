from dataclasses import dataclass
from typing import Callable, List, Any, Sequence

ScoreFn = Callable[[Sequence[float]], float]

@dataclass
class ResonanceSearch:
    """Упрощённый поиск резонансных точек Ω: R(H_i, x) > τ.

    Здесь R абстрактен и задаётся ScoreFn.
    Это не оптимизированный алгоритм — лишь демонстрация идеи O(n^2) отбора.
    """
    threshold: float = 0.5
    max_points: int = 400

    def search(self, R: ScoreFn, candidates: List[Sequence[float]]) -> List[Sequence[float]]:
        # Наивная фильтрация + усечение до max_points
        selected = [x for x in candidates if R(x) > self.threshold]
        return selected[: self.max_points]
