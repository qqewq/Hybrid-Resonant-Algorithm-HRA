from dataclasses import dataclass
from typing import Protocol, Any, Sequence
import math

class Spectrum(Protocol):
    def amplitude(self, k: int) -> float: ...
    def phase(self, k: int) -> float: ...

@dataclass
class ResonanceParams:
    D: float = 2.0  # фрактальная размерность (заглушка)
    q_over_m: Sequence[float] = (1.0, 1.0)  # список q_k / m_k (заглушка)

class ResonanceOperator:
    """Формальная оболочка резонансного оператора R.

    Это НЕ физически корректная модель. Каркас для подключения ваших формул.
    """
    def __init__(self, params: ResonanceParams) -> None:
        self.params = params

    def omega_res(self) -> float:
        if self.params.D == 0:
            return float("inf")
        return (1.0 / self.params.D) * sum(self.params.q_over_m)

    def standing_wave(self, x: float, t: float, A: float = 1.0, k: float = 1.0) -> complex:
        # Ψ(x,t) = 2A cos(kx) * e^{-i ω_res t}
        omega = self.omega_res()
        return 2.0 * A * math.cos(k * x) * complex(math.cos(-omega*t), math.sin(-omega*t))
